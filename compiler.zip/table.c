#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "table.h"
#include "syntax.h"

static unsigned int hash(char *s0)
{
  unsigned int h = 0;
  char *s;
  for (s = s0; *s; s++)
    h = h * 65599 + *s;
  return h;
}

Bucket create_bucket(char *key, void *binding, Bucket next) {
  Bucket bucket = malloc(sizeof(*bucket));
  if (bucket == NULL) {
    fprintf(stderr, "Error: out of memory\n");
    exit(EXIT_FAILURE);
  }
  bucket->key = key;
  bucket->next = next;
  return bucket;
}

SymbolTable create_table() {
  int size = sizeof(Bucket) * SIZE;
  SymbolTable table = malloc(size);
  memset(table, 0, size);
  return table;
}

void destroy_table(SymbolTable table) {
  free(table);
}

void insert(Scope scope, char *key, void *binding) {
  SymbolTable table = scope->table;
  int index = hash(key) % SIZE;
  table[index] = create_bucket(key, binding, table[index]);
  printf("inserted %s key at index %d\n", key, index);
}

void *lookup(Scope scope, char *key) {
  SymbolTable table = scope->table;
  int index = hash(key) % SIZE;
  printf("looking up key %s with index %d at scope %d\n", key, index, scope->kind);
  Bucket bucket;
  for (bucket = table[index]; bucket; bucket = bucket->next) {
    if (strcmp(bucket->key, key) == 0) {
      printf("found bucket with key %s\n", key);
      return bucket->binding;
    }
  }
  return NULL;
}

void *full_lookup(Scope scope, char *key) {
  while (NULL != scope) {
    void *result = (void *)lookup(scope, key);
    // printf("%s\n", ()result->key);
    if (result != NULL) {
      printf("returned from func\n");
      return result;
    }
    scope = scope->parent;
  }
  return NULL;
}

void pop(SymbolTable table, char *key) {
  int index = hash(key) % SIZE;
  table[index] = table[index]->next;
}

Scope create_scope(Scope parent, ScopeKind kind) {
  Scope scope = malloc(sizeof(*scope));
  scope->kind = kind;
  scope->table = create_table();
  scope->parent = parent;
  return scope;
}

void destroy_scope(Scope scope) {
  free(scope);
}

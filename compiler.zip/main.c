#include <stdio.h>
#include <stdlib.h>

#include "syntax.h"
#include "semanthic.h"
#include "parser.tab.h"

extern FILE *yyout, *astout;
extern NodeProgram program;

int main(int argc, char **argv) {
  yyout = fopen("lex.out","w");
  astout = fopen("ast.out", "w");
  yyparse();
  fflush(yyout);
  check_prog(program);
  print_program(program, 0);
}

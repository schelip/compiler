bison -d --verbose parser.y
lex -l lexer.l
gcc main.c lex.yy.c parser.tab.c syntax.c table.c semanthic.c -o compiler
./compiler < test.src